LOGO KM INSERITO

Il progetto ora usa:
- assets/logo.png -> icona/logo mostrato dalla finestra Kivy;
- assets/logo.ico -> icona dell'applicazione Windows generata con PyInstaller.

Per generare l'app:
1. Aprire genera_app.bat su Windows.
2. L'app viene generata in: dist\\Kristin Cassa\\Kristin Cassa.exe
3. Il progetto usa una build ONEDIR per mantenere persistenti SQLite e cache_foto.
