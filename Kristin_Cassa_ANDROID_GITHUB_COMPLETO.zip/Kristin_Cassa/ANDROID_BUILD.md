# Kristin Cassa - Android

Il progetto usa Kivy + Buildozer/python-for-android.

## Build locale

```bash
buildozer -v android debug
```

Il file APK viene generato nella cartella `bin/`.

## Build automatico su GitHub

Il workflow `.github/workflows/android.yml` esegue automaticamente la compilazione su push su `main`/`master` oppure manualmente da **Actions > Build APK Android > Run workflow**.

L'APK viene pubblicato come artifact della build GitHub Actions.

## Database e dati

Su Android il database SQLite e la cache delle foto vengono copiati al primo avvio nella directory privata dell'app. In questo modo l'APK non tenta di scrivere dentro il pacchetto installato.

Il progetto contiene attualmente un database popolato e una chiave di cifratura locale. **Per questo motivo il repository GitHub deve essere privato** se questi dati devono essere mantenuti nel progetto.

## Stampa Android

Il codice prevede già l'invio a RawBT tramite Intent. Sul telefono deve essere installata/configurata RawBT e l'opzione Android/RawBT deve essere abilitata nel Setup dell'app.
