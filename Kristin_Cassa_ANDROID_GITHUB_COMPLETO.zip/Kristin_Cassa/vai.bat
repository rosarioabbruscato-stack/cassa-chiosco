python main.py

pause