[app]
# Titolo e identificativo dell'app
title = Kristin Cassa
package.name = kristincassa
package.domain = ch.kristin

# Versione letta anche da main.py
version = 1.0.0

# Directory del progetto
source.dir = .
source.include_exts = py,png,jpg,jpeg,kv,atlas,db,key,txt,csv
source.exclude_dirs = bin,.buildozer,__pycache__,.git,backup
source.exclude_exts = pyc,pyo

# Dipendenze Python per Android
requirements = python3,kivy,pyjnius,cryptography,openpyxl

# Asset principale / icona launcher
icon.filename = %(source.dir)s/assets/logo.png

# Finestra Kivy
orientation = all
fullscreen = 0

# Android
android.api = 36
android.minapi = 24
android.ndk = 28c
android.archs = arm64-v8a
android.accept_sdk_license = True
android.allow_backup = True
android.private_storage = True

# Nessun permesso di storage esterno: il database e le foto sono nell'area privata dell'app.

# Build debug predefinita; per release usare: buildozer android release
