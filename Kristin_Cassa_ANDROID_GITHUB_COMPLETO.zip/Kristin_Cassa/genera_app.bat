@echo off
setlocal
cd /d "%~dp0"

echo ========================================
echo   KRISTIN CASSA - GENERAZIONE APP
echo ========================================
echo.

echo [1/3] Installazione/aggiornamento PyInstaller...
python -m pip install --upgrade pyinstaller
if errorlevel 1 goto :error

echo.
echo [2/3] Generazione applicazione Windows...
REM ONEDIR: il database SQLite e la cartella cache_foto restano persistenti.
python -m PyInstaller --noconfirm --clean --windowed --name "Kristin Cassa" --icon "assets\logo.ico" --add-data "assets;assets" main.py
if errorlevel 1 goto :error

echo.
echo [3/3] Copia dei dati persistenti nell'app...
if exist "Kristina_DB.sqlite3" copy /Y "Kristina_DB.sqlite3" "dist\Kristin Cassa\Kristina_DB.sqlite3" >nul
if exist "cache_foto" xcopy /E /I /Y "cache_foto" "dist\Kristin Cassa\cache_foto" >nul

echo.
echo ========================================
echo   COMPLETATO
echo  Applicazione: dist\Kristin Cassa\Kristin Cassa.exe
echo  Logo EXE:      assets\logo.ico
echo  Logo finestra: assets\logo.png
echo ========================================
pause
exit /b 0

:error
echo.
echo ERRORE durante la generazione.
pause
exit /b 1
