# -*- coding: utf-8 -*-
# pip install --upgrade pip command
# pip install kivy
# pip install cryptography
# pip install openpyxl

__version__ = "1.0.0"
import os
import sys

from kivy.app import App
import storage
import z_report
import cassa_report
from kivy.uix.screenmanager import ScreenManager
from ui.ui_cassa import InterfacciaCassa
from ui.ui_magazzino import InterfacciaMagazzino
from ui.ui_chiusura import InterfacciaChiusura

def resource_path(relative_path):
    """Restituisce il percorso dell'asset sia in sviluppo sia nell'app PyInstaller."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, relative_path)


class CassaApp(App):
    # Logo mostrato nella finestra/app Kivy.
    icon = resource_path(os.path.join("assets", "logo.png"))

    def build(self):
        storage.init()
        storage.init_settings()
        storage.init_articles()
        z_report.setup()
        cassa_report.setup()
        storage.migrate_legacy()
        self.sm = ScreenManager()
        
        self.cassa_screen = InterfacciaCassa(name="cassa")
        self.mag_screen = InterfacciaMagazzino(name="magazzino")
        self.chiusura_screen = InterfacciaChiusura(name="chiusura")
        
        self.sm.add_widget(self.cassa_screen)
        self.sm.add_widget(self.mag_screen)
        self.sm.add_widget(self.chiusura_screen)
        
        return self.sm

if __name__ == "__main__":
    CassaApp().run()
